from .docgen import *

__doc__ = docgen.__doc__
if hasattr(docgen, "__all__"):
    __all__ = docgen.__all__